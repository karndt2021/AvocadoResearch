# Clear global environment
rm(list = ls())

# Load required packages
library(RMySQL)
library(forecast)
library(caret)

# Connect to SQL
db <- RMySQL::dbConnect(RMySQL::MySQL(), dbname = 'avocado', username='root',password='hamburger')


# Query time series data for region from SQL warehouse
result <- RMySQL::dbSendQuery(db,"select c.DateTime, a.`Total Volume` from dim_calendar as c, dim_region as r, dim_type as t, fact_avocado as a
where a.Date_Key = c.Date_Key and a.Region_Key = r.Region_Key and r.region = 'Tampa'
and a.Type_Key = t.Type_Key and t.Type_Key = 'conventional'")

avocado <- dbFetch(result, n = 169)
dbClearResult(result)

# Convert DateTime to Date datatype
avocadoDate <- strptime(avocado[,1], '%Y-%m-%d')
avocado$DateTime <- avocadoDate

# Convert Total Volume to Numeric
avocadoTotalVol <- as.numeric(avocado$`Total Volume`)
avocado$`Total Volume` <- avocadoTotalVol

# Split the data into a training and testing set
# There are 169 total periods in the time series, so
# the training set will contain the first 135 periods
# and the testing set the final 34 periods.
# The following data division code will work for a time series
# of any length.
dataDivide = as.integer(length(avocado[,1])*0.8)

avoTrain <- avocado[1:dataDivide,]
avoTest <- avocado[(dataDivide+1):length(avocado[,1]),]

# Plot training data to determine whether it is stationary
plot(x = avoTrain$DateTime, y = avoTrain$`Total Volume`, type = "l")
abline(h = mean(avoTrain$`Total Volume`)) # Trendline crosses mean many times, but average does appear to move over time
                                          # Data likely not stationary.

library(urca)
avoTrain$`Total Volume`%>%ur.kpss()%>%summary()
# Test statistic: 0.4363, greater than 10pct and 5pct critical values. Data may or may not be stationary.

ndiffs(avoTrain$`Total Volume`)
# One difference necessary to make data stationary.
# Logarithmic transformation will be applied due to the high level of variance in the data.

# Transform data with one difference and one logarithmic
d1_log_train <- diff(log(avoTrain$`Total Volume`))
d1_log_test <- diff(log(avoTest$`Total Volume`))

trainTrans <- data.frame(avoTrain[2:length(avoTrain$DateTime),1],d1_log_train)
colnames(trainTrans) <- c("Date","Total Volume")
testTrans <- data.frame(avoTest[2:length(avoTest$DateTime),1],d1_log_test)
colnames(testTrans) <- c("Date","Total Volume")

# Plot ACF and PACF
Acf(trainTrans$`Total Volume`,lag.max = 64, plot = TRUE)
# Large negative spike at first period
# Large spikes roughly every 18 periods

Pacf(trainTrans$`Total Volume`,lag.max = 64, plot = TRUE)
# Slowly decaying PACF
# Three large negative spikes first three periods
# Large spikes at periods 8, 27, 50


# Transform data into time series objects
tsTrain <- ts(data = trainTrans$`Total Volume`, start = c(2015,2), end = c(2017,31), frequency = 52)
tsTest <- ts(data = testTrans$`Total Volume`, start = c(2017,33), end = c(2018,12), frequency = 52)

# Use Auto Arima to Estimate a Time Series Model
avoModel <- auto.arima(tsTrain) # AICc = 30.74

avoModel2 <- Arima(tsTrain,order=c(1,0,1),seasonal=list(order=c(0,0,1),period=52))
# ARIMA(1,0,1)(0,0,1)[52] AICc = 24.7

# Plot residuals and asses remaining variation
acf(avoModel$residuals) # One remaining significant negative spike at period 10
pacf(avoModel$residuals) # One remaining significant negative spike at period 10
Box.test(avoModel$residuals, type="Ljung",lag=1)
# p-value = 0.9429, cannot reject the null hypothesis that the data is independently distributed.

# Plot residuals and asses remaining variation
acf(avoModel2$residuals) # One remaining significant negative spike at period 10
pacf(avoModel2$residuals) # One remaining significant negative spike at period 10
Box.test(avoModel2$residuals, type="Ljung",lag=1)
# p-value = 0.9429, cannot reject the null hypothesis that the data is independently distributed.


# Use model to forecast Total Volume in the test period
forecast1<-forecast::forecast(avoModel,h=32)
accuracy1 <- accuracy(forecast1,tsTest)
Models <- data.frame(accuracy1[2,1:5])
colnames(Models) <- c('Auto ARIMA')

# Use model to forecast Total Volume in the test period
forecast2<-forecast::forecast(avoModel2,h=32)
accuracy2 <- accuracy(forecast2,tsTest)
Models2 <- data.frame(accuracy2[2,1:5])
colnames(Models2) <- c('S-ARIMA')

# Plot Train, Test, and Forecast
par(mai=c(0.5,0.5,0.5,0.5))
plot(tsTrain,type="l",
     ylab="Weekly Percent Change in Total Volume",xlab="Period",xlim=c(2015.0,2018.192), main="S-ARIMA")
lines(tsTest,col="orange",lwd=2)
lines(forecast2$mean,col="green",lwd=2)
abline(v=2017.596,lty=2)
legend(2015.0, -0.4, legend=c("Test", "Forecast"),
       col=c("orange","green"), 
       lty=c(1,1,2,2), cex=0.6, text.font=1, bg='lightblue')

# Forecast Data Using stlf()

stlModel <- stlf(tsTrain)
forecast3 <- forecast::forecast(stlModel,h=32)
accuracy3 <- accuracy(forecast3,tsTest)
Models3 <- data.frame(accuracy3[2,1:5])
colnames(Models3) <- c('STL')

# Plot residuals and asses remaining variation
acf(stlModel$residuals) # Several remaining significant spikes in residual ACF and PACF
pacf(stlModel$residuals) 
Box.test(stlModel$residuals, type="Ljung",lag=1)
# p-value < 0.05, data is not independently distributed.


# Plot Train, Test, and Forecast
par(mai=c(0.8,0.8,0.8,0.8))
plot(tsTrain,type="l",
     ylab="Change in Volume (%)",xlab="Period",xlim=c(2015.0,2018.192), main="STL Forecast")
lines(tsTest,col="orange",lwd=2)
lines(forecast3$mean,col="green",lwd=2)
abline(v=2017.596,lty=2)
legend(2015.0, -0.4, legend=c("Test", "Forecast"),
       col=c("orange","green"), 
       lty=c(1,1,2,2), cex=0.6, text.font=1, bg='lightblue')

# Run Leave-One-Out Cross Validation on ARIMA and STL Forecast

farima <- function(x,h) {
  forecast::forecast(Arima(x,order=c(1,0,1),seasonal=list(order=c(0,0,1),period=52)),h=h)
}

arimaerror <- tsCV(tsTrain,farima,h=1)
arimaRMSE <- sqrt(mean(arimaerror^2,na.rm=TRUE))

fstl<-function(x,h){
  forecast::forecast(stlf(x),h=h)
}

stlerror<-tsCV(tsTrain,fstl,h=1)
stlRMSE<-sqrt(mean(stlerror^2,na.rm=TRUE))

fens <- function(x,h){
  0.54*forecast(Arima(x,order=c(1,0,1),seasonal=list(order=c(0,0,1),period=52)),h=h)$mean+(1-0.54)*forecast(stlf(x),h=h)$mean
}

enserror <- tsCV(tsTrain, fens, h=1)
ensCVRMSE <- sqrt(mean(enserror^2, na.rm=TRUE))

# Create ARIMA and STL Ensemble Model
alpha <- seq(from = 0.01, to = 1.0, by = 0.01)
ensRMSE <- c()

for (i in 1:length(alpha)) {
  ens<-alpha[i]*forecast2$mean+(1-alpha[i])*forecast3$mean
  ensRMSE[i]<-sqrt(mean((tsTest-ens)^2))
}
which.min(ensRMSE)
min(ensRMSE) # Using auto ARIMA and STL ensemble, minimum RMSE (0.21885) found at alpha = 0.55.
             # Using calculated auto ARIMA and STL ensemble, minimum RMSE (0.21794) found at alpha 0.54.

a <- 0.54
ens<-a*forecast2$mean+(1-a)*forecast3$mean

par(mai=c(0.8,0.8,0.8,0.8))
plot(tsTrain,type="l",
     ylab="Weekly Change (%)",xlab="Period",xlim=c(2015.0,2018.192), main="Ensemble")
lines(tsTest,col="orange",lwd=2)
lines(ens,col="green",lwd=2)
abline(v=2017.596,lty=2)
legend(2015.0, -0.4, legend=c("Test", "Forecast"),
       col=c("orange","green"), 
       lty=c(1,1,2,2), cex=0.6, text.font=1, bg='lightblue')

(ME<-mean(tsTest-ens))                     #Mean Error
(RMSE<-sqrt(mean((tsTest-ens)^2)))         #Root Mean Squared Error
(MAE<-mean(abs(tsTest-ens)))               #Mean Absolute Error
(MPE<-mean((tsTest-ens)/tsTest)*100)         #Mean Percent Error
(MAPE<-mean(abs((tsTest-ens)/tsTest))*100)   #Mean Absolute Percentage

ensemble<-data.frame(c(ME,RMSE,MAE,MPE,MAPE))
ensemble
colnames(ensemble) <- c('Ensemble')
Models$STL <- Models3
Models$Ensemble <- ensemble

# Run Leave-One-Out Cross Validation on Ensemble Model
